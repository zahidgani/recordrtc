<!DOCTYPE html>
<html>
<head>
	<title>View</title>
</head>
<body>
<video width="320" height="240" controls>
  <source src="uploads/RecordRTC-202118-9qsirt3uple.webm" type="video/webm">

  Your browser does not support the video tag.
</video>
</body>
</html>