<?php
//convert_to_mp4.php
// $a=9.524342345234;
// echo ceil($a).'<br>'.round($a).'<br>'.number_format($a,2);

// $date = '2021-02-11 09:21:22';
// $datei  =strtotime($date);
// echo "<br><br>".date("h:ia",strtotime($date))." to ".date("h:ia",strtotime('+1 minutes',$datei));;
//exit();
ini_set('display_errors', 1);
error_reporting(E_ALL);


try{

exec('/usr/local/bin/ffmpeg -i /Users/zahidgani/Sites/recordrst/uploads/1.webm /Users/zahidgani/Sites/recordrst/uploads/1111.mp4');
echo "Converted";
}catch(Exception $ex){
	echo $ex->getMessage();
}